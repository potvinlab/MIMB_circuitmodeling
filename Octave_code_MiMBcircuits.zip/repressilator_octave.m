%% MiMB Chapter Usign modeling to (re)design synthetic circuits
% Example Code for Repressilator - Octave compatible version
% Giselle McCallum
% 02/07/2019

clear all; close all;

% Mass Action: 
% 0 --> m_i : f(p_i-1) = lambda_m * K^h / (K^h + P_i^h)
% m_i --> 0 : beta_m
% m_i --> P_i : lambda_p
% P_i --> 0 : P_i * beta_p

% Parameter Definitions (units): 
beta_p = 1; % protein elimination rate (setting to 1 sets time units into protein lifetimes - scale other rate values)(tau_p^-1)
beta_m = 0.1*(25/log(2)); % mRNA elimination rate constant (tau_p^-1)(assuming 25 min protein halflife) 

lambda_m = 4.1*(25/log(2)); % max transcription rate constant (mRNAs tau_p^-1)
lambda_p = 1.8*(25/log(2)); % translation rate constant (proteins mRNA^-1 tau_p^-1)

h = 2; % Hill coefficient of cooperativity
K = 7; % Repression threshold (1/2 of all repressors are bound)

% Solve/Simulate
% ODE model ---------------------------------------------------------------

p = [lambda_m, lambda_p, beta_m, beta_p, h, K]; % Parameter vector to hand to ODE solver

% Set initial conditions:
x0 = [10;0;0;0;0;0]; %[m1, P1, m2, P2, m3, P3] - cannot be symmetrical for deterministic system to oscillate

% Time vector:
t_span = 0:.1:1000;

% Call solver:
[t1,x1] = ode23(@repressilator_derivatives,t_span,x0,p); % [time, copy number] = ode23s(odes, time vector, initial conditions, and parameter vector)

% Stochastic Simulations --------------------------------------------------

% Stoichiometry matrix: M x N matrix, where M is number of
% species, N is number of reactions, value indicates change number of
% molecules if that reaction occurs
stoich_mat=[...         reactions: prod_m1, deg_m1, prod_P1, deg_P1, prod_m2, deg_m2, prod_P2, deg_P2, prod_m3, deg_m3,prod_P3, deg_P3; 
                        % Species:
    1 -1 0 0 0 0 0 0 0 0 0 0 ; %m1
    0 0 1 -1 0 0 0 0 0 0 0 0 ; %pf1
    0 0 0 0 1 -1 0 0 0 0 0 0 ; %m2
    0 0 0 0 0 0 1 -1 0 0 0 0 ; %pf2
    0 0 0 0 0 0 0 0 1 -1 0 0 ; %m3
    0 0 0 0 0 0 0 0 0 0 1 -1 ; %pf3
    ];

% Simulation settings
n = 2.5e5; % Number of iterations of Gillespie

% Rate vector function
rvf= @(x)([lambda_m*K^h/(K^h+x(6)^h) (beta_m+beta_p)*x(1) lambda_p*x(1)  beta_p*x(2) ...
        lambda_m*K^h/(K^h+x(2)^h) (beta_m+beta_p)*x(3) lambda_p*x(3)  beta_p*x(4) ...
        lambda_m*K^h/(K^h+x(4)^h) (beta_m+beta_p)*x(5) lambda_p*x(5)  beta_p*x(6)]);

% Call Gillespie function    
[t2,x2,tau] = gillespie(x0,rvf,stoich_mat,n); % [time, copy number, tau leap] = gillespie(initial conditions, rate vector function, stoich matrix, number interations to run);
    
% Resample result matrix at regular time intervals - makes vector rt evenly spaced
t_resample = mean(tau);
[rt,rx] = resample(t2,x2,t_resample); %[resampled time, copy number at new times] = resample(time vector from Gillespie, copy numbers from gillespie, resample interval )

% Plot results
figure('Renderer', 'painters', 'Position', [10 10 1200 700]) % set size of figure
hold on

sp1 =subplot(2,1,1);
h = plot(t1,x1(:,2:2:6),'linewidth',2); % Plots protein copy number only, for mRNA, plot rows 1,3,5
xlim([0 100]);

l=legend('P1','P2','P3');
set(l,'location','northeast')
title('Deterministic Solution')
yl = ylabel('Copy Number');
set(yl,'Position',[-8 -8 -8]);
set(h, {'color'}, {[0.7882    0.2118    0.2118]; [0.9686    0.7333    0.1765]; [0.0039    0.3059    0.5686]});


sp2 = subplot(2,1,2);
h2=plot(t2,x2(2:2:6,:),'linewidth',2);
xlim([0  100]); xlabel('Time (\tau_P)')
title('Stochastic Simulation')
set(h2, {'color'}, {[0.7882    0.2118    0.2118]; [0.9686    0.7333    0.1765]; [0.0039    0.3059    0.5686]});


%%  Calculate and plot autocorrelation
ac = autocorrelation(rx); % Calculates autocorrelation of simulation time traces
[peaks,locations] = findpeaks(real(ac(20:end)),'DoubleSided'); % finds the first peak of the autocorrelation function - must start a bit into the function or findpeaks finds 'first peak' at 0

if isempty(peaks) == 1 % If there is no peak, you don't have oscillations
    period = 0;
    precision = 0;
else
    pks = pks(peaks>0);
    locs = locs(peaks>0);
    period = rt(locs(1)); % period is the time value at the first peak in autocorrelation
    precision = pks(1); % precision is the autocorrelation value at the first peak
end

figure('Renderer', 'painters', 'Position', [10 10 800 700]) % set size of figure
hold on
plot(rt,ac,'linewidth',4);
scatter(rt(locs(1)),pks(1),200,'v','MarkerEdgeColor','k','MarkerfaceColor','r','LineWidth',2);
xlim([0 40]);

xlabel('Time (\Delta\tau_P)');
ylabel('Concentration ACF');



