function [rt,rx] = resample(t,x,n_re)

rt = (0:floor(t(end)/n_re)-1)*n_re;
rx = zeros(size(x,1),length(rt));

rx(:,1) = x(:,1); %initial conditions

% count through t, when t is just below rt(i), record this value as
% rx(i), then start counting through t again until you reach rt(i+1):

I = 1;
for i=2:length(rt)
    while t(I) < rt(i)
        I=I+1;
    end
    rx(:,i) = x(:,I-1);  
end

end